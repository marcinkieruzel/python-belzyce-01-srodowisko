"""kantor 2.0 — przelicza kwoty między dowolnymi walutami po stałych kursach (kursy fikcyjne, do ćwiczeń).

Zmiany niezgodne z wersją 1.x:
- przelicz() przyjmuje trzy argumenty: kwotę, walutę źródłową i walutę docelową,
- słownik KURSY zastąpiła funkcja kurs(waluta).
"""

__version__ = "2.0.0"

_KURSY_PLN = {"PLN": 1.0, "EUR": 4.25, "USD": 3.90, "GBP": 5.00, "CZK": 0.17, "UAH": 0.10}


def kurs(waluta):
    """Ile złotych kosztuje 1 jednostka waluty."""
    return _KURSY_PLN[waluta]


def waluty():
    """Lista obsługiwanych walut."""
    return sorted(_KURSY_PLN)


def przelicz(kwota, z_waluty, na_walute):
    """Przelicza kwotę z jednej waluty na drugą, np. przelicz(100, "EUR", "PLN") -> 425.0."""
    return round(kwota * _KURSY_PLN[z_waluty] / _KURSY_PLN[na_walute], 2)
