"""kantor 1.0 — przelicza złotówki na waluty obce po stałych kursach (kursy fikcyjne, do ćwiczeń)."""

__version__ = "1.0.0"

# ile złotych kosztuje 1 jednostka waluty
KURSY = {
    "EUR": 4.25,
    "USD": 3.90,
    "GBP": 5.00,
    "CZK": 0.17,
    "UAH": 0.10,
}


def przelicz(kwota_pln, waluta):
    """Ile waluty dostaniesz za kwotę w złotych, np. przelicz(100, "EUR") -> 23.53."""
    return round(kwota_pln / KURSY[waluta], 2)
